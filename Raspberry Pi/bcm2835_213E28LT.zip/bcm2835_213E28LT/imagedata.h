

extern const unsigned char IMAGE_BUTTERFLY[];

/* FILE END */


