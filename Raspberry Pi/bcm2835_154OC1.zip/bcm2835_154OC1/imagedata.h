

extern const unsigned char IMAGE_DATA[];
extern const unsigned char gImage_white[]; 

/* FILE END */


