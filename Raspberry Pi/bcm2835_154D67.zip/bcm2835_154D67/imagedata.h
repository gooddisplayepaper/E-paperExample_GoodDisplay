

extern const unsigned char IMAGE_DATA[];
extern const unsigned char gImage_white[]; 
extern const unsigned char gImage_num1[]; 
extern const unsigned char gImage_num2[]; 
extern const unsigned char gImage_num3[]; 
extern const unsigned char gImage_logo[]; 
/* FILE END */


