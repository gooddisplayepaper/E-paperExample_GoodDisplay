#ifndef __DATA_H
#define __DATA_H


extern unsigned char wf_mode;

#endif /* __DATA_H */
